
import Image from "next/image";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { motion } from "framer-motion";

const questions = [
  {
    section: "Team & Operations",
    items: [
      { q: "Do you have clearly defined roles and responsibilities for all staff members?", type: "yesno" },
      { q: "Describe your current staff training process:", type: "text" },
      { q: "Do you have daily or weekly team huddles to align goals and schedules?", type: "yesno" },
      { q: "How do you address staff accountability and performance?", type: "text" },
      { q: "What systems are in place for tracking patient flow and appointment efficiency?", type: "text" },
    ],
  },
  {
    section: "Financial Systems & Case Acceptance",
    items: [
      { q: "What is your average case acceptance rate?", type: "text" },
      { q: "Do you provide financial consultations to every patient receiving a treatment plan?", type: "yesno" },
      { q: "Which financing options do you offer (in-house, CareCredit, Proceed, etc.)?", type: "text" },
      { q: "Are patients informed of financial options before discussing treatment costs?", type: "yesno" },
      { q: "Describe your collections process from patient agreement to final payment:", type: "text" },
    ],
  },
  {
    section: "Marketing & Patient Growth",
    items: [
      { q: "How many new patients do you attract monthly?", type: "text" },
      { q: "Where do most of your new patients come from (Google, insurance, referrals)?", type: "text" },
      { q: "Do you use social media or online reviews as part of your marketing strategy?", type: "yesno" },
      { q: "Do you have a referral rewards program for existing patients?", type: "yesno" },
      { q: "What percentage of patients return for hygiene and recall visits?", type: "text" },
    ],
  },
  {
    section: "Vision & Leadership",
    items: [
      { q: "What are your top 3 goals for the next 12 months?", type: "text" },
      { q: "What is the biggest obstacle standing in your way of growth?", type: "text" },
      { q: "Do you feel confident in your ability to lead your team through change?", type: "yesno" },
      { q: "Have you worked with a consultant or coach in the past?", type: "yesno" },
      { q: "What does success look like for your practice?", type: "text" },
    ],
  },
];

export default function PracticeAssessmentForm() {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState({});

  const handleChange = (question, value) => {
    setResponses({ ...responses, [question]: value });
  };

  const section = questions[step];
  const isLastStep = step === questions.length - 1;

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6">
      <div className="flex justify-center">
        <Image src="/Bespokepracticelogo.PNG" alt="Bespoke Practice Solutions Logo" width={200} height={200} />
      </div>
      <h1 className="text-3xl font-bold text-center">Bespoke Practice Solutions</h1>
      <p className="text-center text-muted-foreground">
        Your Practice. Your Vision. Our Strategy.
      </p>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} key={section.section}>
        <Card>
          <CardContent className="space-y-4">
            <h2 className="text-xl font-semibold">{section.section}</h2>
            {section.items.map((item, index) => (
              <div key={index} className="space-y-2">
                <label className="font-medium">{item.q}</label>
                {item.type === "yesno" ? (
                  <div className="space-x-4">
                    <label>
                      <input
                        type="radio"
                        name={item.q}
                        value="Yes"
                        onChange={() => handleChange(item.q, "Yes")}
                      /> Yes
                    </label>
                    <label>
                      <input
                        type="radio"
                        name={item.q}
                        value="No"
                        onChange={() => handleChange(item.q, "No")}
                      /> No
                    </label>
                  </div>
                ) : (
                  <Textarea
                    placeholder="Your answer..."
                    onChange={(e) => handleChange(item.q, e.target.value)}
                  />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
      <div className="flex justify-between pt-4">
        {step > 0 && <Button onClick={() => setStep(step - 1)}>Back</Button>}
        {isLastStep ? (
          <Button onClick={() => alert("Form submitted!\n" + JSON.stringify(responses, null, 2))}>Submit</Button>
        ) : (
          <Button onClick={() => setStep(step + 1)}>Next</Button>
        )}
      </div>
    </div>
  );
}
